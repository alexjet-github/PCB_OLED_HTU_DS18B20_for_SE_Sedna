In drill files:


"Start of file name"_Holes_Non_Plated.drl - drill TYPE=NON_PLATED
"Start of file name"_Holes_Plated.drl - drill TYPE=PLATED

"Start of file name"_Holes_All.drl - All holes of the PCB (Plated.drl + Non_Plated.drl)!!!